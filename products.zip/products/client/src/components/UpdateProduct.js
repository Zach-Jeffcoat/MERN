import React,{useState, useEffect} from "react";
import axios from "axios";
import {navigate} from "@reach/router";

const UpdateProduct = (props)=>{
	
	const [title, setTitle]=useState("{title}");
	const [price, setPrice] = useState("{price}");
	const [description, setDescription] =useState("{description}");
	
	const {id} = props;
	
	useEffect(()=>{
		axios.get(`http://localhost:8000/api/products/${id}`)
	//backticks allow interpolation, or calling using JSX
	
	const editHandler=(e, req, res)=>{
		e.preventDefault();

		axios.put("http://localhost:8000/api/products" + id)
		({title, price,description})
        .then((res) => {
			console.log(res.data);
			setTitle(res.data.title);
			setPrice(res.data.price);
			setDescription(res.data.description);
			navigate("/")
		})
        .catch((err)=>console.log(err))
		}, [id]);
		
		


	return(
		<div>
			<header>Product Manager</header>
			<form onSubmit={submitHandler} >
				<div className="form-fields">
					<label>Title:</label>
					<input onChange={(e)=>setTitle(e.target.value)} value={title} name="title" type="text" />
					<label>Price:</label>
					<input onChange={(e)=>setPrice(e.target.value)} value={price} name="price" type="number" />
					<label>Description:</label>
					<input onChange={(e)=>setDescription(e.target.value)} value={description} name="description" type="text" />
		<button>Update!</button>
                </div>
            </form>
		</div>
	)
}
