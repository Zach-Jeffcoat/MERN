import React, {useState, useEffect} from "react";
import axios from "axios";
import {navigate} from "@reach/router";

const DisplayOneProduct = (props)=>{
	const {id}= props;
	const[oneProduct, setOneProduct]=useState({});
	
	useEffect(()=>{
		axios.get("http://localhost:8000/api/products/" + id)
		    .then((res)=>{
				console.log(res.data);
				setOneProduct(res.data);
			})
			.catch((err)=>console.log(err)
			)
		}, [id])
		
    const deleteHandler =(()=>{
            axios.delete(`http://loca;host:8000/api/products/${id}`)
                .then((res) => {
                    console.log(res.data);
                    navigate("/");
                })
                .catch((err) => console.log(err));
        },[id])

		
    return(
		<div>
			{oneProduct.title}
            {oneProduct.price}
            {oneProduct.description}
			<button onClick={deleteHandler}>Delete!</button>
		    </div>
        )
    }
