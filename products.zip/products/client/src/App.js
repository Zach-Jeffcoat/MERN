import "./App.css"
import UpdateProduct from "./components/UpdateProduct.js";
import DisplayOne from "./components/DisplayOne.js";
import {Router} from "@reach/router";
import Main from ".";

function App() {
	return(
		<div className="App">
			<Router>
				<Main path="/" />
				<DisplayOne path="/product/:id" />
				<UpdateProduct path="product/:id" />
      </Router>
    </div>
  )
}
export default App;
