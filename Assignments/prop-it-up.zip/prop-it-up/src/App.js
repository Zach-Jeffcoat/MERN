import './App.css';
import PersonCard from './components/PersonCard';

function App() {
  return (
    <div className="App">
      <PersonCard firstName={'John'} lastName={'Stanham'} age={24} hairColor={'Auburn'}/>
      <PersonCard firstName={'Jennifer'} lastName={'Inskeep'} age={28} hairColor={'Dirty Blonde'}/>
      <PersonCard firstName={'Larrisa'} lastName={'Hall'} age={34} hairColor={'Brunette'}/>
      <PersonCard firstName={'Sean'} lastName={'Kiser'} age={33} hairColor={'Raven Black'}/>
    </div>
  );
}

export default App;
